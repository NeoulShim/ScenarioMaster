# Google Docs 출력 뷰어 설치 (개발판)

Google Docs에서 플레인 텍스트를 함께 편집하고, 문서에 달린 뷰어에서 대본 문법을 해석해 HWPX·PDF로 출력합니다. Marketplace에 게시된 확장 프로그램은 아니며, 문서에 직접 설치하는 Apps Script 개발판입니다. 실제 Google Docs에서 테스트 배포 메뉴·미리보기·문서 읽기를 확인했습니다. Google 환경에서의 파일 다운로드·인쇄 검증은 진행 중입니다.

정식 스토어 등록 전의 수동 설치용 개발판입니다. 현재는 설치·사용 통계를 외부로 보내지 않습니다.

프로젝트 이름과 원고 문서 제목은 자유입니다. ‘제목 없는 프로젝트’여도 작동합니다. 단, HTML 파일 이름 `Viewer`는 대문자 V까지 그대로 써야 합니다. [그림 없이도 한 단계씩 따라가는 설치 안내](https://neoulshim.github.io/ScenarioMaster/install.html)를 참고하세요.

1. 사용할 Google Docs에서 **확장 프로그램 → Apps Script**를 엽니다.
2. `Code.gs`의 내용을 붙여 넣습니다.
3. **+ → HTML**로 `Viewer` 파일을 만든 뒤 제공된 `Viewer.html` 전체를 붙여 넣습니다.
4. 프로젝트 설정에서 **appsscript.json 매니페스트 파일 표시**를 켜고 제공된 `appsscript.json`으로 설정합니다. 고급 Google Docs 서비스가 등록됩니다. 표준 Cloud 프로젝트를 쓰면 Google Cloud Console에서도 Google Docs API를 활성화합니다.
5. 저장하고 Docs를 새로고침합니다. **확장 프로그램**에서 이 프로젝트의 메뉴를 열고 **원고 미리보기 / 내보내기**를 선택합니다. 첫 실행의 Google 권한 요청을 확인합니다. 바운드 개발판은 프로젝트 이름이 메뉴에 표시될 수 있습니다.
6. **현재 Docs 읽기**를 누르고 양식과 출력 범위(모든 탭 / 현재 탭)를 선택합니다. **한글 HWPX**는 파일을 내려받습니다. **PDF 저장 / 인쇄**는 새 출력 창을 열며, 인쇄 대상에서 **PDF로 저장**을 선택합니다. 배율 100%, 여백 없음, 브라우저 머리글·바닥글 끄기를 사용하세요.
7. 원문은 Docs에서 편집합니다. **Docs 최신 내용 읽기**로 변경을 반영합니다. 마지막 읽은 시간이 표시되고 선택한 탭·양식·문법은 유지됩니다. 뷰어는 Docs 편집을 막지 않는 창으로 열립니다.

## 수정 이력

원고의 수정 이력과 이전 버전 복원은 Google Docs 기본 버전 기록을 사용합니다.

## 데이터와 권한

원본에 쓰지는 않으며 뷰어에서 주기적으로 최신 내용을 읽습니다. 공동 편집과 원본 이력은 Google Docs가 담당합니다. 서버 코드는 현재 열린 문서의 ID만 사용해 읽습니다. OAuth 읽기 권한의 범위는 계정 문서이지만 코드는 파일 검색이나 다른 문서 읽기를 수행하지 않습니다. 원고는 Google Apps Script와 브라우저 사이에서 이동하고 별도 서비스로 보내지 않습니다. 공유 문서의 바운드 스크립트는 문서 편집자가 확인·수정할 수 있습니다.

공식 문서: [문서 탭](https://developers.google.com/workspace/docs/api/how-tos/tabs), [수정 제안](https://developers.google.com/workspace/docs/api/how-tos/suggestions), [대화상자](https://developers.google.com/apps-script/guides/dialogs).

HWPX 기본 패키지 출처와 Apache-2.0 라이선스는 `THIRD_PARTY_NOTICES.md`, `LICENSE-python-hwpx.txt`를 확인하세요.
