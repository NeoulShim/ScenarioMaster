/** Google Docs Editor add-on. Reads only after an explicit user action. */
function onOpen(e) {
  // Menu construction must also work before authorization (AuthMode.NONE).
  DocumentApp.getUi().createAddonMenu()
    .addItem('원고 미리보기 / 내보내기', 'showScenarioMaster')
    .addItem('문서 옆 뷰어 열기', 'showScenarioSidebar')
    .addItem('사용법 및 데이터 안내', 'showScenarioHelp').addToUi();
}
function onInstall(e) {
  onOpen(e);
}
function showScenarioHelp() {
  DocumentApp.getUi().showModalDialog(
    HtmlService.createHtmlOutput('<!doctype html><html lang="ko"><head><base target="_blank"></head><body style="font:14px/1.8 sans-serif;padding:20px"><h2>시나리오의 거장</h2><p>원고 미리보기 창에서 현재 Docs 읽기를 누르세요. 원문을 수정하지 않고 대본 양식으로 미리보기·HWPX 다운로드·PDF 인쇄를 제공합니다.</p><p>원고는 Google Apps Script와 사용자 브라우저 사이에서 처리됩니다. 원고·문서 제목·이메일을 별도 분석 서버로 보내지 않습니다.</p><p><a href="https://neoulshim.github.io/ScenarioMaster/syntax.html" rel="noopener noreferrer">상세 문법 보기</a></p><p>QA 2026.09.16-1 개발판입니다. 설치 안내: https://neoulshim.github.io/ScenarioMaster/install.html</p></body></html>').setWidth(480).setHeight(380),
    '사용법 및 데이터 안내'
  );
}
function showScenarioMaster() {
  DocumentApp.getUi().showModelessDialog(createScenarioViewer('dialog').setWidth(1440).setHeight(1000), '시나리오의 거장');
}
function showScenarioSidebar() {
  DocumentApp.getUi().showSidebar(createScenarioViewer('sidebar').setTitle('시나리오의 거장'));
}
function loadScenarioPreferences() {
  return PropertiesService.getUserProperties().getProperty('scenario.preferences.v1') || '';
}
function saveScenarioPreferences(text) {
  if (typeof text !== 'string' || Utilities.newBlob(text).getBytes().length > 8500) throw Error('기본 설정이 너무 큽니다. 양식 파일로 보관해 주세요.');
  const p = JSON.parse(text);
  if (p.version !== 1 || !p.template || !p.syntax || typeof p.autoRefresh !== 'boolean' || Object.keys(p).some(k => !['version','template','syntax','templateKey','autoRefresh'].includes(k))) throw Error('기본 설정 형식이 올바르지 않습니다.');
  PropertiesService.getUserProperties().setProperty('scenario.preferences.v1', text);
  return 'saved';
}
function readActiveScenarioDocument() {
  const doc = DocumentApp.getActiveDocument();
  if (!doc) throw new Error('Google Docs 문서에서 실행해 주세요.');
  return JSON.stringify(Docs.Documents.get(doc.getId(), {
    includeTabsContent: true,
    suggestionsViewMode: 'PREVIEW_WITHOUT_SUGGESTIONS'
  }));
}

// Only the already-authorized effective user's token, for the active document.
function createScenarioReadSession() {
  const doc = DocumentApp.getActiveDocument();
  if (!doc) throw new Error('Google Docs 문서에서 실행해 주세요.');
  return { documentId: doc.getId(), accessToken: ScriptApp.getOAuthToken() };
}

// Read during the authorized menu action, before the iframe starts RPC calls.
function createScenarioViewer(windowMode) {
  const bootstrap = {
    windowMode: windowMode || 'dialog',
    document: JSON.parse(readActiveScenarioDocument()),
    preferences: '',
    preferencesError: false
  };
  try { bootstrap.preferences = loadScenarioPreferences(); }
  catch (error) { bootstrap.preferencesError = true; }
  try { bootstrap.readSession = createScenarioReadSession(); } catch (error) { /* Standard RPC remains available. */ }
  const safeJson = JSON.stringify(bootstrap).replace(/</g, '\\u003c');
  const html = HtmlService.createHtmlOutputFromFile('Viewer').getContent();
  return HtmlService.createHtmlOutput(html.replace('<head>',
    '<head><script id="scenario-bootstrap" type="application/json">' + safeJson + '</script>'));
}
