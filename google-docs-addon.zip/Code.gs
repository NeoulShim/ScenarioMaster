/** @OnlyCurrentDoc */
/** Google Docs Editor add-on. Reads only after an explicit user action. */
function onOpen(e) {
  // Menu construction must also work before authorization (AuthMode.NONE).
  DocumentApp.getUi().createAddonMenu()
    .addItem('원고 미리보기 / 내보내기', 'showScenarioMaster')
    .addItem('문서 옆 뷰어 열기', 'showScenarioSidebar')
    .addItem('사용법 및 데이터 안내', 'showScenarioHelp').addToUi();
}
function onInstall(e) {
  onOpen(e);
}
function showScenarioHelp() {
  DocumentApp.getUi().showModalDialog(
    HtmlService.createHtmlOutput('<!doctype html><html lang="ko"><head><base target="_blank"></head><body style="font:14px/1.8 sans-serif;padding:20px"><h2>시나리오의 거장</h2><p>원고 미리보기 창에서 현재 Docs 읽기를 누르세요. 원문을 수정하지 않고 대본 양식으로 미리보기·HWPX 다운로드·PDF 인쇄를 제공합니다.</p><p>원고는 Google Apps Script와 사용자 브라우저 사이에서 처리됩니다. 원고·문서 제목·이메일을 별도 분석 서버로 보내지 않습니다.</p><p><a href="https://neoulshim.github.io/ScenarioMaster/syntax.html" rel="noopener noreferrer">상세 문법 보기</a></p><p>버전 1.0.0 · 도움말: https://neoulshim.github.io/ScenarioMaster/support.html</p></body></html>').setWidth(480).setHeight(380),
    '사용법 및 데이터 안내'
  );
}
function showScenarioMaster() {
  DocumentApp.getUi().showModelessDialog(createScenarioViewer('dialog').setWidth(1440).setHeight(1000), '시나리오의 거장');
}
function showScenarioSidebar() {
  DocumentApp.getUi().showSidebar(createScenarioViewer('sidebar').setTitle('시나리오의 거장'));
}
function loadScenarioPreferences() {
  return PropertiesService.getUserProperties().getProperty('scenario.preferences.v1') || '';
}
function saveScenarioPreferences(text) {
  if (typeof text !== 'string' || Utilities.newBlob(text).getBytes().length > 8500) throw Error('기본 설정이 너무 큽니다. 양식 파일로 보관해 주세요.');
  const p = JSON.parse(text);
  if (p.version !== 1 || !p.template || !p.syntax || typeof p.autoRefresh !== 'boolean' || Object.keys(p).some(k => !['version','template','syntax','templateKey','autoRefresh'].includes(k))) throw Error('기본 설정 형식이 올바르지 않습니다.');
  PropertiesService.getUserProperties().setProperty('scenario.preferences.v1', text);
  return 'saved';
}
function readActiveScenarioDocument() {
  const doc = DocumentApp.getActiveDocument();
  if (!doc) throw new Error('Google Docs 문서에서 실행해 주세요.');
  return JSON.stringify(serializeScenarioDocument_(doc));
}

// Read during the authorized menu action, before the iframe starts RPC calls.
function createScenarioViewer(windowMode) {
  const bootstrap = {
    windowMode: windowMode || 'dialog',
    document: JSON.parse(readActiveScenarioDocument()),
    preferences: '',
    preferencesError: false
  };
  try { bootstrap.preferences = loadScenarioPreferences(); }
  catch (error) { bootstrap.preferencesError = true; }
  const safeJson = JSON.stringify(bootstrap).replace(/</g, '\\u003c');
  const html = HtmlService.createHtmlOutputFromFile('Viewer').getContent();
  return HtmlService.createHtmlOutput(html.replace('<head>',
    '<head><script id="scenario-bootstrap" type="application/json">' + safeJson + '</script>'));
}

// Serialize only the active container document with DocumentApp.
// The structure matches our importer; no Docs REST or OAuth tokens are used.
function serializeScenarioDocument_(doc) {
  let imageCount = 0, imageBytes = 0, nodes = 0;
  const warnings = [];
  function readTab(tab, depth) {
    if (depth > 10) throw Error('탭 계층이 너무 깊습니다.');
    const scope = { inlineObjects: {}, positionedObjects: {} };
    let imageSequence = 0;
    function image(image, positioned) {
      const id = 'image-' + imageSequence++;
      const embedded = {
        size: { width: { magnitude: image.getWidth() * 0.75, unit: 'PT' }, height: { magnitude: image.getHeight() * 0.75, unit: 'PT' } },
        imageProperties: {}
      };
      try {
        if (++imageCount > 40) throw Error('한 문서에서 최대 40개까지 읽습니다');
        let blob = image.getBlob();
        if (!['image/png','image/jpeg'].includes(blob.getContentType())) blob = image.getAs('image/png');
        const bytes = blob.getBytes();
        if (bytes.length > 4000000 || imageBytes + bytes.length > 6000000) throw Error('이미지 용량을 줄여 주세요');
        imageBytes += bytes.length;
        embedded.scenarioImageSource = 'data:' + blob.getContentType() + ';base64,' + Utilities.base64Encode(bytes);
        // Stable content identity invalidates the browser cache on replacement.
        embedded.imageProperties.contentUri = 'native:' + Utilities.base64Encode(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, bytes));
      } catch (error) { embedded.scenarioImageError = String(error); }
      const map = positioned ? scope.positionedObjects : scope.inlineObjects;
      map[id] = positioned ? { positionedObjectProperties: { embeddedObject: embedded } } : { inlineObjectProperties: { embeddedObject: embedded } };
      return id;
    }
    function paragraph(p) {
      const elements = [];
      for (let i=0;i<p.getNumChildren();i++) {
        const child=p.getChild(i), type=String(child.getType());
        if (type === 'TEXT') {
          const text=child.asText(), value=text.getText(), offsets=text.getTextAttributeIndices();
          for (let j=0;j<offsets.length;j++) {
            const start=offsets[j], end=j+1<offsets.length?offsets[j+1]:value.length;
            if (end>start) elements.push({textRun:{content:value.slice(start,end),textStyle:{bold:text.isBold(start) === true,italic:text.isItalic(start) === true}}});
          }
        } else if (type === 'INLINE_IMAGE') elements.push({inlineObjectElement:{inlineObjectId:image(child.asInlineImage(),false)}});
        else if (type === 'PAGE_BREAK') elements.push({pageBreak:{}});
        else if (type === 'HORIZONTAL_RULE') elements.push({horizontalRule:{}});
        else if (type === 'FOOTNOTE') elements.push({footnoteReference:{}});
        else if (typeof child.getText === 'function') elements.push({textRun:{content:child.getText(),textStyle:{}}});
        else warnings.push('일부 문서 요소를 읽지 못했습니다. 출력 전 원고와 비교해 주세요.');
      }
      elements.push({textRun:{content:'\n',textStyle:{}}});
      const align=String(p.getAlignment());
      return {paragraph:{elements,paragraphStyle:{alignment:align==='RIGHT'?'END':align==='LEFT'?'START':'CENTER'},positionedObjectIds:typeof p.getPositionedImages==='function'?p.getPositionedImages().map(im=>image(im,true)):[]}};
    }
    function container(parent, level) {
      if (level>20) throw Error('문서 내용의 계층이 너무 깊습니다.');
      const content=[];
      for(let i=0;i<parent.getNumChildren();i++) {
        if(++nodes>30000) throw Error('문서가 너무 큽니다.');
        const child=parent.getChild(i),type=String(child.getType());
        if(type==='PARAGRAPH'||type==='LIST_ITEM') content.push(paragraph(child));
        else if(type==='TABLE') {
          const table=child.asTable(),rows=[];
          for(let r=0;r<table.getNumRows();r++) {
            const row=table.getRow(r),cells=[];
            for(let c=0;c<row.getNumCells();c++)cells.push({content:container(row.getCell(c),level+1)});
            rows.push({tableCells:cells});
          }
          content.push({table:{tableRows:rows}});
        } else if(type!=='TABLE_OF_CONTENTS') warnings.push('일부 문서 요소를 읽지 못했습니다. 출력 전 원고와 비교해 주세요.');
      }
      return content;
    }
    scope.body={content:container(tab.asDocumentTab().getBody(),0)};
    return {tabProperties:{tabId:tab.getId(),title:tab.getTitle()},documentTab:scope,childTabs:tab.getChildTabs().map(t=>readTab(t,depth+1))};
  }
  const tabs=doc.getTabs().map(t=>readTab(t,0));
  return {documentId:doc.getId(),title:doc.getName(),tabs,scenarioWarnings:[...new Set(warnings)]};
}
