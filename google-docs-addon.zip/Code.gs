/** Google Docs Editor add-on. Reads only after an explicit user action. */
function onOpen(e) {
  // Menu construction must also work before authorization (AuthMode.NONE).
  DocumentApp.getUi().createAddonMenu()
    .addItem('원고 미리보기 / 내보내기', 'showScenarioMaster')
    .addItem('문서 옆 뷰어 열기', 'showScenarioSidebar')
    .addItem('사용법 및 데이터 안내', 'showScenarioHelp').addToUi();
}
function onInstall(e) {
  onOpen(e);
}
function showScenarioHelp() {
  DocumentApp.getUi().showModalDialog(
    HtmlService.createHtmlOutput('<!doctype html><html lang="ko"><head><base target="_blank"></head><body style="font:14px/1.8 sans-serif;padding:20px"><h2>시나리오의 거장</h2><p>원고 미리보기 창에서 현재 Docs 읽기를 누르세요. 원문을 수정하지 않고 대본 양식으로 미리보기·HWPX 다운로드·PDF 인쇄를 제공합니다.</p><p>원고는 Google Apps Script와 사용자 브라우저 사이에서 처리됩니다. 원고·문서 제목·이메일을 별도 분석 서버로 보내지 않습니다.</p><p><a href="https://neoulshim.github.io/ScenarioMaster/syntax.html" rel="noopener noreferrer">상세 문법 보기</a></p><p>QA 2026.09.16-1 개발판입니다. 설치 안내: https://neoulshim.github.io/ScenarioMaster/install.html</p></body></html>').setWidth(480).setHeight(380),
    '사용법 및 데이터 안내'
  );
}
function showScenarioMaster() {
  DocumentApp.getUi().showModelessDialog(createScenarioViewer('dialog').setWidth(1440).setHeight(1000), '시나리오의 거장');
}
function showScenarioSidebar() {
  DocumentApp.getUi().showSidebar(createScenarioViewer('sidebar').setTitle('시나리오의 거장'));
}
function loadScenarioPreferences() {
  return PropertiesService.getUserProperties().getProperty('scenario.preferences.v1') || '';
}
function saveScenarioPreferences(text) {
  if (typeof text !== 'string' || Utilities.newBlob(text).getBytes().length > 8500) throw Error('기본 설정이 너무 큽니다. 양식 파일로 보관해 주세요.');
  const p = JSON.parse(text);
  if (p.version !== 1 || !p.template || !p.syntax || typeof p.autoRefresh !== 'boolean' || Object.keys(p).some(k => !['version','template','syntax','templateKey','autoRefresh'].includes(k))) throw Error('기본 설정 형식이 올바르지 않습니다.');
  PropertiesService.getUserProperties().setProperty('scenario.preferences.v1', text);
  return 'saved';
}
function readActiveScenarioDocument() {
  const doc = DocumentApp.getActiveDocument();
  if (!doc) throw new Error('Google Docs 문서에서 실행해 주세요.');
  const data = Docs.Documents.get(doc.getId(), {
    includeTabsContent: true,
    suggestionsViewMode: 'PREVIEW_WITHOUT_SUGGESTIONS'
  });
  attachScenarioImages_(doc, data);
  return JSON.stringify(data);
}

// Only the already-authorized effective user's token, for the active document.
function createScenarioReadSession() {
  const doc = DocumentApp.getActiveDocument();
  if (!doc) throw new Error('Google Docs 문서에서 실행해 주세요.');
  return { documentId: doc.getId(), accessToken: ScriptApp.getOAuthToken() };
}

// Read during the authorized menu action, before the iframe starts RPC calls.
function createScenarioViewer(windowMode) {
  const bootstrap = {
    windowMode: windowMode || 'dialog',
    document: JSON.parse(readActiveScenarioDocument()),
    preferences: '',
    preferencesError: false
  };
  try { bootstrap.preferences = loadScenarioPreferences(); }
  catch (error) { bootstrap.preferencesError = true; }
  try { bootstrap.readSession = createScenarioReadSession(); } catch (error) { /* Standard RPC remains available. */ }
  const safeJson = JSON.stringify(bootstrap).replace(/</g, '\\u003c');
  const html = HtmlService.createHtmlOutputFromFile('Viewer').getContent();
  return HtmlService.createHtmlOutput(html.replace('<head>',
    '<head><script id="scenario-bootstrap" type="application/json">' + safeJson + '</script>'));
}

// Read image bytes through the already-authorized document service (no external fetch scope).
function attachScenarioImages_(doc, data) {
  if (!data.tabs || !doc.getTabs) return;
  const nativeTabs = {};
  function collect(tabs) { tabs.forEach(t => { nativeTabs[t.getId()] = t; collect(t.getChildTabs()); }); }
  collect(doc.getTabs());
  let totalBytes = 0, count = 0;
  function attach(embedded, image) {
    if (!embedded || !image || ++count > 40) return;
    try {
      let blob = image.getBlob();
      if (!['image/png', 'image/jpeg'].includes(blob.getContentType())) blob = image.getAs('image/png');
      const bytes = blob.getBytes();
      if (bytes.length > 4000000 || totalBytes + bytes.length > 6000000) return;
      totalBytes += bytes.length;
      embedded.scenarioImageSource = 'data:' + blob.getContentType() + ';base64,' + Utilities.base64Encode(bytes);
    } catch (error) { /* Client displays a placeholder and retries, never silently drops it. */ }
  }
  function visit(tab) {
    const scope = tab.documentTab, native = nativeTabs[tab.tabProperties.tabId];
    if (scope && native) {
      const body = native.asDocumentTab().getBody(), ids = [];
      function scan(content) {
        (content || []).forEach(el => {
          if (el.paragraph) (el.paragraph.elements || []).forEach(part => {
            if (part.inlineObjectElement) ids.push(part.inlineObjectElement.inlineObjectId);
          });
          if (el.table) el.table.tableRows.forEach(row => row.tableCells.forEach(cell => scan(cell.content)));
        });
      }
      scan(scope.body && scope.body.content);
      const images = body.getImages();
      // Do not guess correspondence when Google exposes different object counts.
      if (images.length === ids.length) ids.forEach((id, i) => attach(scope.inlineObjects[id].inlineObjectProperties.embeddedObject, images[i]));
      body.getParagraphs().forEach(paragraph => paragraph.getPositionedImages().forEach(image => {
        const item = (scope.positionedObjects || {})[image.getId()];
        if (item) attach(item.positionedObjectProperties.embeddedObject, image);
      }));
    }
    (tab.childTabs || []).forEach(visit);
  }
  data.tabs.forEach(visit);
}
